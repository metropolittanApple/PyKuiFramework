import setuptools

setuptools.setup(
    name = "Pykui_test13",
    version="1.0",
    author="Paul Cannon Palacios and Pau Cava de las Heras",
    author_email="alt.f4.studios.dev@gmail.com",
    description="Make graphics easier and faster!",
    long_description="PyKui is a module that is based on pygame and it makes graphics easier and faster!",
    license="Free for everyone"
)